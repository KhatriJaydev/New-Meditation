// export var single = [
//   {
//     name1: 'Monday',
//     name: 'M',
//     value: 40632,
//   },
//   {
//     name1: 'Tuesday',
//     name: 'T',
//     value: 20000,
//   },
//   {
//     name1: 'Wednesday',
//     name: 'W',
//     value: 33000,
//   },
//   {
//     name1: 'Thursday',
//     name: 'T ',
//     value: 10000,
//   },
//   {
//     name1: 'Friday',
//     name: 'F',
//     value: 44606,
//   },
//   {
//     name1: 'Saturday',
//     name: 'S',
//     value: 10000,
//   },
//   {
//     name1: 'Sunday',
//     name: 'S ',
//     value: 20000,
//   },
// ];
