import { Component } from '@angular/core';
import { fade } from 'src/app/animations/animations';

@Component({
  selector: 'app-explore',
  templateUrl: './explore.component.html',
  styleUrls: ['./explore.component.scss'],
  animations: [fade]
})
export class ExploreComponent {

}
