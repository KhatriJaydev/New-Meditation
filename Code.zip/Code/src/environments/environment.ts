export const environment = {
    production: false,
    baseURL:'http://106.201.232.190:5001'
  };